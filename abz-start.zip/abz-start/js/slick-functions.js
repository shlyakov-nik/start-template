$(document).ready(function(){
	$('.slicker').slick({
		autoplay: true,
		autoplaySpeed: 2000,
		infinite: true,
		dots: false,
		arrows: false,
		adaptiveHeight: false,
		cssEase: 'linear',
		fade: true,
		lazyLoad: 'progressive',
		mobileFirst: true, 
		centerMode: true,
		centerPadding: '0px', 
		respondTo: 'slider',
		speed: 2000,
	});
});
